package ATM;

import java.util.ArrayList;

public class ATMApp {
    public static ArrayList<User> users = new ArrayList<>();
    public static User currentUser = null;
    public static Login loginScreen = null;
}
